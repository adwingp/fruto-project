
    <!-- footer start -->
    <div class="project_area">
        <div class="container">
            <div class="row">
                 <div class="col-xl-4 col-md-6 col-lg-4" style="text-align: center; margin-top: 5px;">
                        <div class="footer_widget">
                            <p>
                                <h4 style="color: white">Follow Us On</h4>
                            </p>
                            <div style="margin-top: 13%;">
                                <ul>
                                    <li>
                                        <a href="#">
                                            <img width="35px" class="ti-facebook" src="public/img/social-media/twitter.svg"></img>
                                        </a>
                                        <a href="#">
                                            <img style="margin-left: 10px;" width="35px" class="ti-facebook" src="public/img/social-media/linkedin.svg"></img>
                                        </a>
                                        <a href="#">
                                            <img style="margin-left: 10px;" width="35px" class="ti-facebook" src="public/img/social-media/instagram.svg"></img>
                                        </a>
                                        <a href="#">
                                            <img style="margin-left: 10px;" width="35px" class="ti-facebook" src="public/img/social-media/fb.svg"></img>
                                        </a>
                                        <a href="#">
                                            <img style="margin-left: 10px;" width="35px" class="ti-facebook" src="public/img/social-media/bing.svg"></img>
                                        </a>
                                        <a href="#">
                                            <img style="margin-left: 10px;" width="35px" class="ti-facebook" src="public/img/social-media/google-plus.svg"></img>
                                        </a>
                                    </li>
                                    
                                </ul>
                            </div>
                            

                        </div>
                        
                    </div>
                <div class="col-xl-4 col-md-6 col-lg-4 footer-more">
                    <div class="project_info text-center">
                        <h4>Do you Have any Project?</h4>
                        <p>Nam libero tempore, cum soluta nobis est eligendi optio <br>
                            cumque nihil impedit quo minus.</p>
                        <a href="contact-us" class="boxed-btn3-white">Contact Us</a>
                    </div>
                </div>
                 <div class="col-xl-4 col-md-6 col-lg-4 footer-more">
                        <div class="footer_widget">
                            <h4 class="footer_title" style="color: white;   margin-bottom: 24px;">I - EON PRIVATE LIMITED </h4>
                                 <p class="footer_p">Trivandrum, Kerala</p>
                                 <p class="footer_p">+10 367 467 8934</p>
                                 <p class="footer_p">i-eon@gmail.com </p>
                            </ul>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    <footer class="footer">
        <div class="copy-right_text">
            <div class="container">
                <div class="footer_border"></div>
                <div class="row">
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                            <a href="#" style="    float: left;"> <img width: 100px; src="public/img/footer_logo.png" alt=""> </a>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;
                            <script>document.write(new Date().getFullYear());</script> All rights reserved | This
                            Website is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a
                                href="http://www.i-eon.com" target="_blank">I-Eon</a>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--/ footer end  -->

    <!-- link that opens popup -->

    <!-- form itself end-->
    <form id="test-form" class="white-popup-block mfp-hide">
        <div class="popup_box ">
            <div class="popup_inner">
                <div class="popup_header">
                    <h3>Get Free Quote</h3>
                </div>
                <div class="custom_form">
                    <div class="row">
                        <div class="col-xl-12">
                            <input type="text" placeholder="Your Name">
                        </div>
                        <div class="col-xl-12">
                            <input type="email" placeholder="Email">
                        </div>
                        <div class="col-xl-12">
                            <textarea name="" id="" cols="30" rows="10" placeholder="Message"></textarea>
                        </div>
                        <div class="col-xl-12">
                            <button type="submit" class="boxed-btn3">Send</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <!-- form itself end -->